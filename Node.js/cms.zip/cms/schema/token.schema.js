const mongoose = require("mongoose");
const TokenSchema = new mongoose.Schema(
    {
        appId: {
            type: Number,
            require: false
        },
        language: [{
            key: {
                type: String,
                require: false
            },
        }],
        app: {
            type: String,
            require: false
        },
        module: {
            type: String,
            require: false
        },
        uniqueId:{
            type: Number,
            required: true,
        },
    },
    { strict:false,timestamps: true }
);
const TokenModel = mongoose.model("Token", TokenSchema);
module.exports = TokenModel;


