const TokenModel = require("../schema/token.schema");
const BaseService = require("@baapcompany/core-api/services/base.service");

class TokenService extends BaseService {
    constructor(dbModel, entityName) {
        super(dbModel, entityName);
    }
    getAllDataByGroupId(tokenId, criteria) {
        const query = {
            tokenId: tokenId,
        };

        if (criteria.name) query.name = new RegExp(criteria.name, "i");

        return this.preparePaginationAndReturnData(query, criteria);
    }
    async findByKey(key) {
        return this.execute(() => {
            return this.model.findOne({ key: key });
        });
    }
    async findByModule(module) {
        return this.execute(() => {
            return this.model.findOne({ module: module });
        });
    }
    async findByTag(tag) {
        return this.execute(() => {
            return this.model.findOne({ tag: tag });
        });
    }
    async deleteAllByCriteria(criteria) {
        try {
            const deleteResult = await TokenModel.deleteMany(criteria).exec();

            if (deleteResult.deletedCount === 0) {
                return { message: "No tokens found to delete" };
            }
            return { message: "tokens deleted successfully" };
        } catch (error) {
            throw error;
        }
    }
    async getAllDataByKey(key, criteria) {
        const query = {
            key: key,
        };
        if (criteria.key) query.key = criteria.key;

        return this.preparePaginationAndReturnData(query, criteria);
    }
    async  deleteByUniqueId(uniqueId) {
        try {
          const deleteResult = await TokenModel.deleteOne({ uniqueId: uniqueId });
          return deleteResult;
        } catch (error) {
          throw new Error('Error deleting document by uniqueId');
        }
      }
      async updateByUniqueId(uniqueId, updatedData) {
        return this.execute(() => {
            return this.model.findOneAndUpdate({ uniqueId: uniqueId }, updatedData, { new: true });
        });
    }
    
}
module.exports = new TokenService(TokenModel, "Token");
