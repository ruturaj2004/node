const waterTaxModel=require("../schema/waterTax.schema");
const BaseService=require("@baapcompany/core-api/services/base.service");
class waterTaxService extends BaseService{
    constructor(dbModel, entityName){
        super(dbModel,entityName);
    }
    grtAllDataByGroupId(waterTaxId,criteria){
        const query={
            waterTaxId:waterTaxId,
        }
if(criteria.name)query.name=new RegExp(criteria.name ,"i");
return this.preparePaginationAndReturnData(query,criteria)
    }
    async findBy(tax){
        return this.execute(()=>{
            return this.model.findOne({tax:tax}) 
        })
    }
async deleteAllByCriteria(criteria){
    try{
        const deleteResult=await waterTaxModel.deleteMany(criteria).exec();
   if (deleteResult.deleteCount === 0){
    return{message:"No find this filed"};
    }
    return{message:"All taxes are delete successful"};
}catch(error){
throw error;
}}
async getAllDataByTaxationPeriod(taxationPeriod, criteria) {
        const query = {
            taxationPeriod: taxationPeriod,
        };
        if (criteria.taxationPeriod) query.taxationPeriod = criteria.taxationPeriod;

        return this.preparePaginationAndReturnData(query, criteria);
    }
    async  deleteByUniqueId(lgdId) {
        try {
          const deleteResult = await LgdModel.deleteOne({ lgdId: lgdId });
          return deleteResult;
        } catch (error) {
          throw new Error('Error deleting document by lgdId');
        }
      }
      async updateByUniqueId(lgdId, updatedData) {
        return this.execute(() => {
            return this.model.findOneAndUpdate({ lgdId: lgdId }, updatedData, { new: true });
        });
    }
}
module.exports=new waterTaxService(waterTaxModel,"watertax");