const express = require("express");
const router = express.Router();
const { checkSchema } = require("express-validator");
const service = require("../services/lgd.service");
const requestResponsehelper = require("@baapcompany/core-api/helpers/requestResponse.helper");
const ValidationHelper = require("@baapcompany/core-api/helpers/validation.helper");

router.post(
    "/create",
    checkSchema(require("../dto/lgd.dto")),
    async (req, res, next) => {
        if (ValidationHelper.requestValidationErrors(req, res)) {
            return;
        }
        const serviceResponse = await service.create(req.body);
        requestResponsehelper.sendResponse(res, serviceResponse);
    }
);
router.get("/all/lgd", async (req, res) => {
    const serviceResponse = await service.getAllByCriteria({});
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.delete("/DeleteByLgdId/:id", async (req, res) => {
    const serviceResponse = await service.deleteById(req.params.id);
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.put("/updateByLgdId/:id", async (req, res) => {
    const serviceResponse = await service.updateById(req.params.id, req.body);
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.get("/findByLgdId/:id", async (req, res) => {
    const serviceResponse = await service.getById(req.params.id);
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.get("/getBylgdNo/:lgd", async (req, res) => {
    const lgd = req.params.lgd;
    const serviceResponse = await service.findByLgd(lgd);
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.delete("/deleteAllRecords", async (req, res) => {
    const serviceResponse = await service.deleteAllByCriteria({});
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.get("/all/getBylgd/:lgd", async (req, res) => {
    const lgd = req.params.key;
    const criteria = {
        lgd: req.query.lgd,
    };
    const serviceResponse = await service.getAllDataByLgd(
        lgd,
        criteria
    );
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.delete("/deleteDataByLgdId/:lgdId", async (req, res) => {
    try {
      const lgdId = req.params.lgdId;

      const deleteResult = await service.deleteByUniqueId(lgdId);
  
      if (deleteResult) {
        const responseData = {
          status: "Success",
          message: `Data with uniqueId ${lgdId} deleted successfully.`,
        };
        requestResponsehelper.sendResponse(res, responseData);
      } else {
        res.status(404).json({ error: 'Document not found' });
      }
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });

  router.put("/updateDataByLgdId/:lgdId", async (req, res) => {
    const lgdId = req.params.lgdId;
    const updateData = req.body; // Assuming the updated data is sent in the request body

    try {
        const serviceResponse = await service.updateByUniqueId(lgdId, updateData);

        if (serviceResponse) {
            requestResponsehelper.sendResponse(res, serviceResponse);
        } else {
            res.status(404).json({ error: "Document not found" });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});
module.exports = router;
