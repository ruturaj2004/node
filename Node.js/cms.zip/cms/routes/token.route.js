const express = require("express");
const router = express.Router();
const { checkSchema } = require("express-validator");
const service = require("../services/token.service");
const requestResponsehelper = require("@baapcompany/core-api/helpers/requestResponse.helper");
const ValidationHelper = require("@baapcompany/core-api/helpers/validation.helper");
function generateUniqueCode() {
    const min = 100000; 
    const max = 999999; 
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
const { v4: uuidv4 } = require('uuid');
router.post(
  "/create-token",
  checkSchema(require("../dto/token.dto")),
  async (req, res, next) => {
    if (ValidationHelper.requestValidationErrors(req, res)) {
      return;
    }
    
    const uniqueId = generateUniqueCode(); 
    req.body.uniqueId = uniqueId;

    const serviceResponse = await service.create(req.body);
    requestResponsehelper.sendResponse(res, serviceResponse);
  }
);
router.get("/all/tokens", async (req, res) => {
    const serviceResponse = await service.getAllByCriteria({});
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.delete("/DeleteByTokenId/:id", async (req, res) => {
    const serviceResponse = await service.deleteById(req.params.id);
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.put("/updateByTokenId/:id", async (req, res) => {
    const serviceResponse = await service.updateById(req.params.id, req.body);
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.get("/findByTokenId/:id", async (req, res) => {
    const serviceResponse = await service.getById(req.params.id, req.body);
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.get("/getDataByKey/:key", async (req, res) => {
    const key = req.params.key;
    const serviceResponse = await service.findByKey(key);
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.get("/getDataByModule/:module", async (req, res) => {
    const module = req.params.module;
    const serviceResponse = await service.findByModule(module);
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.get("/getDataByTag/:tag", async (req, res) => {
    const tag = req.params.tag;
    const serviceResponse = await service.findByTag(tag);
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.delete("/all/tokens", async (req, res) => {
    const serviceResponse = await service.deleteAllByCriteria({});
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.get("/all/getBykey/:key", async (req, res) => {
    const key = req.params.key;
    const criteria = {
        key: req.query.key,
        pageNumber: parseInt(req.query.pageNumber) || 1,
        pageSize: parseInt(req.query.pageSize) || 10,
    };

    const serviceResponse = await service.getAllDataByKey(
        key,
        criteria
    );
    requestResponsehelper.sendResponse(res, serviceResponse);
});
router.delete("/deleteDataByUniqueId/:uniqueId", async (req, res) => {
    try {
      const uniqueId = req.params.uniqueId;

      const deleteResult = await service.deleteByUniqueId(uniqueId);
  
      if (deleteResult) {
        const responseData = {
          status: "Success",
          message: `Data with uniqueId ${uniqueId} deleted successfully.`,
        };
        requestResponsehelper.sendResponse(res, responseData);
      } else {
        res.status(404).json({ error: 'Document not found' });
      }
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
  router.put("/updateDataByUniqueId/:uniqueId", async (req, res) => {
    const uniqueId = req.params.uniqueId;
    const updateData = req.body; // Assuming the updated data is sent in the request body

    try {
        const serviceResponse = await service.updateByUniqueId(uniqueId, updateData);

        if (serviceResponse) {
            // Document updated successfully, send the updated document in the response
            requestResponsehelper.sendResponse(res, serviceResponse);
        } else {
            // Document with the unique ID was not found
            res.status(404).json({ error: "Document not found" });
        }
    } catch (error) {
        // Handle error, send appropriate response
        console.error(error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

module.exports = router;
