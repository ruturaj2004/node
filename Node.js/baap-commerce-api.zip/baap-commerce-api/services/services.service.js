const { default: mongoose } = require("mongoose");
const CategoryModel = require("../schema/category.schema");
const ServiceModel = require("../schema/services.schema");
const BaseService = require("@baapcompany/core-api/services/base.service");

class ServicesService extends BaseService {
    constructor(dbModel, entityName) {
        super(dbModel, entityName);
    }

    async getAllDataByGroupId(groupId, criteria, lat, lon) {
        const query = {
            groupId: groupId,
        };

        if (criteria.subcategoryId) {
            query.subcategoryId = criteria.subcategoryId;
        }

        if (criteria.parentServiceId) {
            query.parentServiceId = criteria.parentServiceId;
        } else {
            query.parentServiceId = null;
        }

        if (criteria.categoryId) {
            query.categoryId = criteria.categoryId;
        }

        if (!isNaN(lat) && !isNaN(lon)) {
            query.location = {
                $nearSphere: {
                    $geometry: {
                        type: "Point",
                        coordinates: [lat, lon]
                    },
                    $maxDistance: 50000
                }
            }
        }

        const menuItemData = await ServiceModel.find(query);

        if (!menuItemData) {
            return null;
        }

        return this.preparePaginationAndReturnData(query, criteria);
    }



    async getByGroupId(groupId, subcategoryId) {
        return this.execute(async () => {
            const query = {
                groupId: groupId,
                subcategoryId: subcategoryId
            };
            return await this.getAllByCriteria(query);
        });
    }

    async searchByTagsAndName(groupId, lat, lon, search) {
        try {
            const searchFilter = {
                groupId: groupId
            };

            if (lat && lon) {
                searchFilter.location = {
                    $nearSphere: {
                        $geometry: {
                            type: "Point",
                            coordinates: [lat, lon]
                        },
                        $maxDistance: 40000     // 40 kilometers in meters
                    }
                };
            }

            if (search) {
                searchFilter.$or = [
                    { name: { $regex: search, $options: 'i' } },
                    { desc: { $regex: search, $options: 'i' } },
                    { tags: { $in: search.split(",") } }
                ];
            }

            const services = await ServiceModel.find(searchFilter);

            const response = {
                status: "Success",
                data: {
                    items: services,
                    totalItemsCount: services.length
                }
            };

            return response;

        } catch (error) {
            console.error("Error:", error);
            throw error;
        }
    }



}

module.exports = new ServicesService(ServiceModel, "services");
