const jwt = require('jsonwebtoken');

class TokenService {

    static async checkPermission(req, res, next) {
        const token = req.headers.authorization;

        if (!token) {
            return res.status(401).json({ message: "Invalid token, you do not have access to call this" });
        }

        try {
            const decodedToken = await TokenService.decodeToken(token);
            const { userId, name, phoneNumber, servicerequestId, year, month, categoryId, status, search } = req.query;

            let hasPermission = false;

            if (decodedToken.role && decodedToken.role.permissions.includes("get-all")) {
                hasPermission = true;
            } else if (decodedToken.role && decodedToken.role.permissions.includes("LSR", "OSR") && userId || name || phoneNumber || servicerequestId || year || month || categoryId || status || search) {
                hasPermission = true;
            }

            if (hasPermission) {
                next();
            } else {
                return res.status(403).json({ message: "You do not have permission to call this API" });
            }
        } catch (error) {
            console.error('Token verification error:', error.message);
            return res.status(500).json({ message: "Token verification failed" });
        }
    }


    static async decodeToken(token) {
        try {
            console.log('Received token:', token);
            const decoded = jwt.verify(token, process.env.API_SECRET);

            return decoded;
        } catch (error) {
            console.error('Token verification error:', error.message);
            throw new Error('Token verification failed');
        }
    }
}

module.exports = TokenService;