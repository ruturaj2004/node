const ShopModel = require("../schema/shop.schema");
const BaseService = require("@baapcompany/core-api/services/base.service");

class ShopService extends BaseService {
    constructor(dbModel, entityName) {
        super(dbModel, entityName);
    }
    getAllDataByGroupId(groupId, criteria) {
        const query = {
            groupId: groupId,
        };

        if (criteria.shopName) query.shopName = new RegExp(criteria.shopName, "i");

        if (criteria.contactNo) query.contactNo = new RegExp(criteria.contactNo, "i");

        return this.preparePaginationAndReturnData(query, criteria);
    }
}

module.exports = new ShopService(ShopModel, 'shop');
