const LeadModel = require("../schema/ead.schema");
const BaseService = require("@baapcompany/core-api/services/base.service");
class LeadService extends BaseService {
    constructor(dbModel, entityName) {
        super(dbModel, entityName);
    }
    getAllDataByGroupId(leadId, criteria) {
        const query = {
            leadId: leadId,
        };

        if (criteria.name) query.name = new RegExp(criteria.name, "i");

        return this.preparePaginationAndReturnData(query, criteria);
    }
    async findByKey(key) {
        return this.execute(() => {
            return this.model.findOne({ key: key });
        });
    }
    async findByModule(module) {
        return this.execute(() => {
            return this.model.findOne({ module: module });
        });
    }
    async findByTag(tag) {
        return this.execute(() => {
            return this.model.findOne({ tag: tag });
        });
    }
    async deleteAllByCriteria(criteria) {
        try {
            const deleteResult = await LeadModel.deleteMany(criteria).exec();

            if (deleteResult.deletedCount === 0) {
                return { message: "No Leads found to delete" };
            }
            return { message: "Leads deleted successfully" };
        } catch (error) {
            throw error;
        }
    }
    async getAllDataByKey(key, criteria) {
        const query = {
            key: key,
        };
        if (criteria.key) query.key = criteria.key;

        return this.preparePaginationAndReturnData(query, criteria);
    }
    async  deleteByUniqueId(uniqueId) {
        try {
          const deleteResult = await LeadModel.deleteOne({ uniqueId: uniqueId });
          return deleteResult;
        } catch (error) {
          throw new Error('Error deleting document by uniqueId');
        }
      }
      async updateByUniqueId(uniqueId, updatedData) {
        return this.execute(() => {
            return this.model.findOneAndUpdate({ uniqueId: uniqueId }, updatedData, { new: true });
        });
    }
    
}
module.exports = new LeadService(LeadModel, "Lead");
