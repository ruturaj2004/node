const CustomerModel = require("../schema/customer.schema");
const BaseService = require("@baapcompany/core-api/services/base.service");
const ServiceResponse = require("@baapcompany/core-api/services/serviceResponse");
const CartModel = require("../schema/cart.schema");
const { model } = require("mongoose");
const mongoose = require('mongoose');

class CustomerService extends BaseService {
    constructor(dbModel, entityName) {
        super(dbModel, entityName);
    }

    async getAllRequestsByCriteria(criteria) {
        const query = {};

        if (criteria.groupId) {
            query.groupId = criteria.groupId;
        }

        if (criteria.phoneNumber) {
            query.phoneNumber = criteria.phoneNumber;
        }

        return this.getAllByCriteria(query);
    }

    async deleteAddressByGroupIdUserIdAddressId(groupId, userId, addressId) {
        try {
            const customer = await CustomerModel.findOne({ groupId, userId });

            if (!customer) {
                throw new Error("Customer not found");
            }

            const addressIndex = customer.addresses.findIndex((address) => address.addressId == addressId);

            if (addressIndex === -1) {
                throw new Error("Address not found");
            }

            customer.addresses.splice(addressIndex, 1);

            const updatedCustomer = await CustomerModel.findOneAndUpdate(
                { groupId, userId },
                { $set: { addresses: customer.addresses } },
                { new: true }
            );

            if (!updatedCustomer) {
                throw new Error("Failed to update customer");
            }

            return updatedCustomer;
        } catch (error) {
            return {
                status: "Error",
                message: error.message,
            };
        }
    }

    async getByUserId(userId) {
        return this.execute(() => {
            return this.model.findOne({ userId: userId });
        });
    }

    async getAllDataByGroupId(groupId, criteria) {
        const query = {
            groupId: groupId,
        };

        if (criteria.name) query.name = new RegExp(criteria.name, "i");

        if (criteria.phoneNumber) query.phoneNumber = criteria.phoneNumber;
        if (criteria.userId) query.userId = criteria.userId;

        return this.preparePaginationAndReturnData(query, criteria);
    }

    async getByCustId(custId) {
        return this.execute(() => {
            return this.model.findOne({ custId: custId });
        });
    }

    async updateCustomer(custId, data) {
        try {
            const resp = await CustomerModel.findOneAndUpdate(
                { custId: custId },

                data,
                { upsert: true, new: true }
            );

            return new ServiceResponse({
                data: resp,
            });
        } catch (error) {
            return new ServiceResponse({
                isError: true,
                message: error.message,
            });
        }
    }

    async updateCustomerByUserId(userId, newAddress, data) {
        try {
            const conditions = { userId: userId };
            const existingCustomer = await CustomerModel.findOne(conditions);

            if (!existingCustomer) {
                return new ServiceResponse({
                    isError: true,
                    message: 'Customer not found',
                });
            }

            if (newAddress && newAddress.address.default === true) {
                existingCustomer.addresses.forEach((address) => {
                    address.address.default = false;
                });
            }

            if (newAddress) {
                const existingDefaultAddress = existingCustomer.addresses.find(address => address.address.default === true);
                if (existingDefaultAddress && newAddress.address.default === true) {
                    existingDefaultAddress.address.default = false;
                }

                existingCustomer.addresses.push(newAddress);
            }

            if (Object.keys(data).length > 0) {
                for (const field in data) {
                    existingCustomer[field] = data[field];
                }
            }

            const updatedCustomer = await CustomerModel.findOneAndUpdate(
                conditions,
                { $set: { ...existingCustomer.toObject(), ...data } },
                { new: true }
            );

            return new ServiceResponse({
                data: updatedCustomer,
            });
        } catch (error) {
            return new ServiceResponse({
                isError: true,
                message: error.message,
            });
        }
    }

    static async registerUser(userDto) {
        try {
            console.log("Entered register method");
            console.log(userDto);
            const response = await axios.post(
                process.env.AUTH_SERVICE_BASE_URL + "auth/user",
                userDto
            );
            console.log("End register method");
            return new ServiceResponse({
                // data: response.data,
            });
        } catch (error) {
            console.log("Error in register method");
            return new ServiceResponse({
                isError: true,
                message: error.response
                    ? error.response.data.messages
                        ? error.response.data.messages
                        : error.response.data.message
                    : error.message,
            });
        }
    }

    async updateAddress(groupId, userId, addressId, newAddress) {
        try {
            const customer = await CustomerModel.findOne({ groupId, userId });

            if (!customer) {
                throw new Error("Customer not found");
            }

            const addressIndex = customer.addresses.findIndex((address) => address.addressId == addressId);

            if (addressIndex === -1) {
                throw new Error("Address not found");
            }

            newAddress.default = true;

            customer.addresses.forEach((address, index) => {
                if (index !== addressIndex) {
                    address.address.default = false;
                }
            });

            customer.addresses[addressIndex].address = newAddress;

            const updatedCustomer = await CustomerModel.findOneAndUpdate(
                { groupId, userId },
                { $set: { addresses: customer.addresses } },
                { new: true }
            );

            if (!updatedCustomer) {
                throw new Error("Failed to update customer");
            }

            return updatedCustomer;
        } catch (error) {
            throw error;
        }
    }

    async getDefaultAddress(groupId, userId) {
        try {
            const customer = await CustomerModel.findOne({ groupId, userId });

            if (!customer) {
                return new ServiceResponse({
                    message: "Customer not found",
                    data: {},
                    isError: true
                });
            }

            const defaultAddress = customer.addresses.find((address) => address.address.default === true);

            if (!defaultAddress) {
                return new ServiceResponse({
                    data: {},
                    message: "Default address not found",
                    isError: true,
                });
            }

            return new ServiceResponse({
                data: defaultAddress,
            });
        } catch (error) {
            return new ServiceResponse({
                isError: true,
                message: error.message,
            });
        }
    }

    async updateMembership(groupId, userId, membershipId, updateData) {
        try {
            const customer = await CustomerModel.findOne({ groupId, userId });

            if (!customer) {
                return new ServiceResponse({
                    message: "Customer not found",
                    isError: true,
                });
            }

            const membershipToUpdate = customer.memberMembership.find(member => member.membershipId == membershipId);

            if (!membershipToUpdate) {
                return new ServiceResponse({
                    message: "Membership not found for the given ID",
                    isError: true,
                });
            }

            Object.assign(membershipToUpdate, updateData);

            await customer.save();

            return new ServiceResponse({
                message: "Membership updated successfully",
                data: membershipToUpdate,
            });
        } catch (error) {
            return new ServiceResponse({
                isError: true,
                message: error.message,
            });
        }
    }

    async updateCustomerAccountByUserId(userId, groupId, newAccount, data) {
        try {
            const conditions = { userId: userId, groupId: groupId };
            const existingCustomer = await CustomerModel.findOne(conditions);

            if (!existingCustomer) {
                return new ServiceResponse({
                    isError: true,
                    message: 'Customer not found',
                });
            }

            if (newAccount) {
                if (!existingCustomer.accountDetails) {
                    existingCustomer.accountDetails = [];
                }
                const accountId = new mongoose.Types.ObjectId();
                existingCustomer.accountDetails.push({
                    id: accountId,
                    accountId:  +Date.now(),
                    accounts: newAccount.accounts
                });
            }

            if (Object.keys(data).length > 0) {
                for (const field in data) {
                    existingCustomer[field] = data[field];
                }
            }

            const updatedCustomer = await CustomerModel.findOneAndUpdate(
                conditions,
                { $set: { ...existingCustomer.toObject(), ...data } },
                { new: true }
            );

            return new ServiceResponse({
                data: updatedCustomer,
            });
        } catch (error) {
            return new ServiceResponse({
                isError: true,
                message: error.message,
            });
        }
    }

}

module.exports = new CustomerService(CustomerModel, "customer");
