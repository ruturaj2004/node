const mongoose = require("mongoose");

const productsSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
        },
        groupId: {
            type: Number,
            required: true,
        },
        categoryId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "category",
            autopopulate: true,
        },
        categoryId: {
            type: Number
        },
        subcategoryId: {
            type: Number
        },
        subCategoryId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "subcategory",
            autopopulate: true,
        },
        tags:{
            type:Array,
            required :true
        },
        productcode: {
            type: Number
        },
        model: {
            type: String
        },
        description: {
            type: String
        },
        serialNumber: {
            type: Number
        }
    },
    { strict: false, timestamps: false }
);

productsSchema.index({ tags: 1 });
productsSchema.plugin(require("mongoose-autopopulate"));
const ProductsModel = mongoose.model("products", productsSchema);

module.exports = ProductsModel;
