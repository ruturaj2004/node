const mongoose = require("mongoose");
const LeadSchema = new mongoose.Schema(
    {
        appId: {
            type: Number,
            require: false
        },
        language: [{
            key: {
                type: String,
                require: false
            },
        }],
        app: {
            type: String,
            require: false
        },
        module: {
            type: String,
            require: false
        },
        uniqueId:{
            type: Number,
            required: true,
        },
    },
    { strict:false,timestamps: true }
);
const LeadModel = mongoose.model("Lead", LeadSchema);
module.exports = LeadModel;


